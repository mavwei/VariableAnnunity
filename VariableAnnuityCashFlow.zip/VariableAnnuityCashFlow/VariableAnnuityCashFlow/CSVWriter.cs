﻿using System;
using System.IO;
using System.Linq;

namespace VariableAnnuityCashFlow
{
    public class CSVwriter
    {
        private string _filePath;

        public CSVwriter(string filePath)
        {
            _filePath = filePath;
        }

        public void Write(List<string> headers, List<List<string>> data)
        {
            using (var writer = new StreamWriter(_filePath))
            {
                // Write header row
                writer.WriteLine(string.Join(",", headers));

                // Write data rows
                foreach (var row in data)
                {
                    writer.WriteLine(string.Join(",", row));
                }
            }
        }
    }
}

