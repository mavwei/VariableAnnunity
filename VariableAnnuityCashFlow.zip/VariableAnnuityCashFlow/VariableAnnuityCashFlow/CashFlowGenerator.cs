﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Formats.Asn1;
using System.IO;
using System.Linq;
using System.Net.NetworkInformation;
using System.Numerics;
using System.Reflection.PortableExecutable;
using System.Runtime.InteropServices;
using System.Security.Claims;
using System.Text.Json;
using Newtonsoft.Json;
using VariableAnnuityCashFlow;


class CashFlowGenerator
{
    static void Main()
    {

        string VAconfig = File.ReadAllText(@"./../../../Inputs/VariableAnnuityRiskFacotor.json");
        VariableAnnuity? VariableAnnuityRiskFacotor = JsonConvert.DeserializeObject<VariableAnnuity>(VAconfig);

        string mortalityData = File.ReadAllText(@"./../../../Inputs/MortalityTable.json");
        List<Dictionary<string, object>> MortalityData = Newtonsoft.Json.
            JsonConvert.DeserializeObject<List<Dictionary<string, object>>>(mortalityData);
        Dictionary<int, double> MortalityDictionary = new Dictionary<int, double>();
        foreach (Dictionary<string, object> item in MortalityData)
        {
            MortalityDictionary.Add(Convert.ToInt32(item["Age"]), Convert.ToDouble(item["Mortality Rate"]));
        }

        string lapseTable = File.ReadAllText(@"./../../../Inputs/LapseTable.json");
        List<Dictionary<string, object>> LapseTableData = Newtonsoft.Json.
            JsonConvert.DeserializeObject<List<Dictionary<string, object>>>(lapseTable);
        Dictionary<int, double> LapseDataDictionary = new Dictionary<int, double>();
        foreach (Dictionary<string, object> item in LapseTableData)
        {
            LapseDataDictionary.Add(Convert.ToInt32(item["Dur"]),
                Convert.ToDouble(item["ING LifePay Plus Base"]));
        }

        int StartAge = VariableAnnuityRiskFacotor.StartAge;

        List<int> Years = new List<int>();
        List<int> AgeList = new List<int>();

        for (int age = StartAge; age <= VariableAnnuityRiskFacotor.LastDeathAge; age++)
        {
            Years.Add(age - StartAge);
            AgeList.Add(age);
        }

        Fund Fund1 = new Fund();
        Fund Fund2 = new Fund();

        string FundData = File.ReadAllText(@"./../../../Inputs/FundConfig.json");
        var FundDict = JsonConvert.DeserializeObject<Dictionary<string, List<FundConfig>>>(FundData);

        Fund1.Weight = FundDict["Fund1"][0].Weight;
        Fund2.Weight = FundDict["Fund2"][0].Weight;

        string Fund1ReturnJson = File.ReadAllText(@"./../../../Inputs/" + FundDict["Fund1"][0].ReturnScenario);
        var Fund1Returns = JsonConvert.DeserializeObject<List<FundReturn>>(Fund1ReturnJson);
        string Fund2ReturnJson = File.ReadAllText(@"./../../../Inputs/" + FundDict["Fund2"][0].ReturnScenario);
        var Fund2Returns = JsonConvert.DeserializeObject<List<FundReturn>>(Fund2ReturnJson);

        foreach (var Fund1ReturnsItem in Fund1Returns)
        {
            Fund1.AddYearReturn(Fund1ReturnsItem.Return);
        }
        foreach (var Fund2ReturnsItem in Fund2Returns)
        {
            Fund2.AddYearReturn(Fund2ReturnsItem.Return);
        }


        Fund1.AddPreFee(Fund1.Weight * VariableAnnuityRiskFacotor.InitialPremium);
        Fund1.AddPreWithdrawal(Fund1.PreFee[0]);
        Fund1.AddPostWithdrawal(Fund1.PreFee[0]);
        Fund1.AddPostCharges(Fund1.PreFee[0]);
        Fund1.AddPostDeathClaims(Fund1.PreFee[0]);
        Fund1.AddPostRebalance(Fund1.PreFee[0]);

        Fund2.AddPreFee(Fund2.Weight * VariableAnnuityRiskFacotor.InitialPremium);
        Fund2.AddPreWithdrawal(Fund2.PreFee[0]);
        Fund2.AddPostWithdrawal(Fund2.PreFee[0]);
        Fund2.AddPostCharges(Fund2.PreFee[0]);
        Fund2.AddPostDeathClaims(Fund2.PreFee[0]);
        Fund2.AddPostRebalance(Fund2.PreFee[0]);



        List<int> EligibleStepUp = new List<int>(
            new int[] { 0 });
        List<int> GrowthPhase = new List<int>(
            new int[] { 0 });
        List<int> WithdrawalPhase = new List<int>(
            new int[] { 0 });
        List<int> AutomaticPeriodicBenefitStatus = new List<int>(
            new int[] { 0 });
        List<int> LastDeath = new List<int>(
            new int[] { 0 });

        for (int year = 1; year + StartAge <= VariableAnnuityRiskFacotor.LastDeathAge; year++)
        {
            GrowthPhase.Add((AgeList[year] <= VariableAnnuityRiskFacotor.FirstWithdrawalAge
                && AgeList[year] <= VariableAnnuityRiskFacotor.AnnunityCommencementDateAge
                && AgeList[year] < VariableAnnuityRiskFacotor.LastDeathAge) ? 1 : 0);
            EligibleStepUp.Add((year <= VariableAnnuityRiskFacotor.StepUpPeriod
                && GrowthPhase.Last() == 1) ? 1 : 0);
            LastDeath.Add(AgeList[year] == VariableAnnuityRiskFacotor.LastDeathAge ? 1 : 0);
        }



        List<double> Contribution = new List<double>(new double[AgeList.Count]);


        List<double> AVPreFee = new List<double>(
            new double[] { Fund1.PreFee[0] + Fund2.PreFee[0] });
        List<double> MandEFee = new List<double>(
            new double[] { 0.0 });
        List<double> AVPreWithdrawal = new List<double>(
            new double[] { Contribution[0] + AVPreFee[0] - MandEFee[0] });


        List<double> AVPostWithdrawal = new List<double>(
            new double[] { AVPreWithdrawal[0] });

        List<double> AVPostCharges = new List<double>(
            new double[] { AVPostWithdrawal[0] });

        DeathBenefit DeathBenefitCashFlow = new DeathBenefit();
        DeathBenefitCashFlow.AddROPDeathBase(VariableAnnuityRiskFacotor.InitialPremium);
        DeathBenefitCashFlow.AddDeathPayment(0.0);
        DeathBenefitCashFlow.AddNARDeathClaims(Math.Max(DeathBenefitCashFlow.DeathPayment[0] - AVPostCharges[0], 0.0));

        List<double> AVPostDeathClaims = new List<double>(
            new double[] { Math.Max(AVPostCharges[0] - DeathBenefitCashFlow.DeathPayment[0], 0.0) });

        Rider LifePayPlusRider = new Rider();
        LifePayPlusRider.AddDeathBenefitBase(VariableAnnuityRiskFacotor.InitialPremium);
        LifePayPlusRider.AddWithdrawalBase(VariableAnnuityRiskFacotor.InitialPremium);
        LifePayPlusRider.AddWithdrawalAmount(0.0);
        LifePayPlusRider.AddCumulativeWithdrawal(LifePayPlusRider.WithdrawalAmount.Last());
        LifePayPlusRider.AddMaximunAnnualWithdrawal(0.0);
        LifePayPlusRider.AddMaximunAnnualWithdrawalRate(0.0);
        LifePayPlusRider.AddRiderCharge(0.0);

        List<string> KeyList = VariableAnnuityRiskFacotor.MaxAnnualWithdrawal.Keys.ToList();
        string Key = null;
        for (int year = 1; year + StartAge <= VariableAnnuityRiskFacotor.LastDeathAge; year++)
        {
            if (GrowthPhase[year] == 1)
            {
                LifePayPlusRider.AddMaximunAnnualWithdrawalRate(0.0);
            }
            else
            {
                if (double.Parse(KeyList[0]) > Convert.ToDouble(AgeList[year]))
                {
                    LifePayPlusRider.AddMaximunAnnualWithdrawalRate(0.0);
                }
                else if (double.Parse(KeyList.Last()) <= Convert.ToDouble(AgeList[year]))
                {
                    Key = KeyList.Last();
                }
                else
                {
                    for (int KeyIndex = 1; KeyIndex < KeyList.Count; KeyIndex++)
                    {
                        if ((double.Parse(KeyList[KeyIndex - 1]) < Convert.ToDouble(AgeList[year]))
                            && (double.Parse(KeyList[KeyIndex]) > Convert.ToDouble(AgeList[year])))
                        {
                            Key = KeyList[KeyIndex - 1];
                        }
                    }
                }
                LifePayPlusRider.AddMaximunAnnualWithdrawalRate(
                    VariableAnnuityRiskFacotor.MaxAnnualWithdrawal[Key]);
            }
        }



        List<int> RebalanceIndicator = new List<int>(
            new int[] { 0 });
        List<double> WithdrawalClaims = new List<double>(
            new double[] { 0 });


        List<double> DiscountFactor = new List<double>();

        for (int idx = 0; idx < AgeList.Count; idx++)
        {
            DiscountFactor.Add(VariableAnnuityCashFlow.DiscountFactor.CalculateDiscountFactor(VariableAnnuityRiskFacotor.RiskFreeRate, Years[idx]));
        }

        for (int year = 1; year + StartAge <= VariableAnnuityRiskFacotor.LastDeathAge; year++)
        {
            Fund1.AddPreFee(Fund1.PostRebalance.Last() * (1.0 + Fund1.YearReturn[year]));
            Fund2.AddPreFee(Fund2.PostRebalance.Last() * (1.0 + Fund2.YearReturn[year]));
            AVPreFee.Add(Fund1.PreFee[year] + Fund2.PreFee[year]);

            MandEFee.Add(AVPostDeathClaims.Last() *
                (VariableAnnuityRiskFacotor.MandE + VariableAnnuityRiskFacotor.FundFees));
            AVPreWithdrawal.Add(Math.Max(0.0, Contribution[year] + AVPreFee.Last() - MandEFee.Last()));


            Fund1.AddPreWithdrawal(AVPreWithdrawal.Last()==0 ?
                0.0 : Fund1.PreFee.Last() / AVPreFee.Last() * AVPreWithdrawal.Last() );
            Fund2.AddPreWithdrawal(AVPreWithdrawal.Last() == 0 ?
                0.0 : Fund2.PreFee.Last() / AVPreFee.Last() * AVPreWithdrawal.Last());

            WithdrawalPhase.Add(((AgeList[year] > VariableAnnuityRiskFacotor.FirstWithdrawalAge ||
                AgeList[year] > VariableAnnuityRiskFacotor.AnnunityCommencementDateAge) &&
                AVPostDeathClaims.Last() > 0 &&
                AgeList[year] < VariableAnnuityRiskFacotor.LastDeathAge) ? 1 : 0);

            AutomaticPeriodicBenefitStatus.Add((AgeList[year] >= VariableAnnuityRiskFacotor.LastDeathAge) ?
                0 : (WithdrawalPhase[WithdrawalPhase.Count - 2] == 1 &&
                AVPostDeathClaims.Last() == 0) ? 1 : AutomaticPeriodicBenefitStatus.Last());


            RebalanceIndicator.Add(WithdrawalPhase.Last()+ AutomaticPeriodicBenefitStatus.Last());

            DeathBenefitCashFlow.AddDeathPayment(
                (GrowthPhase[year] +WithdrawalPhase[year]
                + AutomaticPeriodicBenefitStatus[year] + LastDeath[year]) == 0 ?
                0:Math.Max(DeathBenefitCashFlow.ROPDeathBase.Last(),
                LifePayPlusRider.DeathBenefitBase.Last()) * MortalityDictionary[year]);

            DeathBenefitCashFlow.AddROPDeathBase(
                DeathBenefitCashFlow.ROPDeathBase.Last() * (1.0 - MortalityDictionary[AgeList[year]]));


            WithdrawalSolver solver = new WithdrawalSolver(
                Contribution[year],
                AVPreWithdrawal[year],
                MandEFee[year],
                VariableAnnuityRiskFacotor.RiderCharge,
                MortalityDictionary[AgeList[year]],
                DeathBenefitCashFlow.DeathPayment[year],
                LifePayPlusRider.WithdrawalBase.Last(),
                LifePayPlusRider.MaximunAnnualWithdrawal.Last(),
                DeathBenefitCashFlow.DeathPayment[year],
                VariableAnnuityRiskFacotor.StepUp,
                EligibleStepUp[year],
                WithdrawalPhase[year],
                AutomaticPeriodicBenefitStatus[year],
                VariableAnnuityRiskFacotor.WithrawalRate,
                LifePayPlusRider.MaximunAnnualWithdrawalRate[year],
                GrowthPhase[year]
                );

            double WithdrawalAmountThisYear = solver.Calculator();
            double AVPostChargesThisYear = solver.CalculateAVPostCharges();
            double AVPostDeathClaimsThisYear = solver.CalculateAVPostDeathClaims();
            double WithdrawBaseThisYear = solver.CalculateWithdrawBase();
            double MaxWithdrawalAmountThisYear = solver.CalculateMaxWithdrawalAmount();
            double AVPostWithdrawalThisYear = solver.CalculateAVPostWithdrawal();
            double RiderChargeThisYear = solver.CalculateRiderCharge();



            AVPostCharges.Add(AVPostChargesThisYear);
            AVPostDeathClaims.Add(AVPostDeathClaimsThisYear);
            LifePayPlusRider.AddWithdrawalBase(WithdrawBaseThisYear);
            LifePayPlusRider.AddWithdrawalAmount(WithdrawalAmountThisYear);
            LifePayPlusRider.AddCumulativeWithdrawal(
                LifePayPlusRider.CumulativeWithdrawal.Last()+ WithdrawalAmountThisYear);
            AVPostWithdrawal.Add(AVPostWithdrawalThisYear);
            LifePayPlusRider.AddRiderCharge(RiderChargeThisYear);
            LifePayPlusRider.AddMaximunAnnualWithdrawal(MaxWithdrawalAmountThisYear);

            Fund1.AddPostWithdrawal(AVPostWithdrawal.Last()==0 ? 0.0 :
                Fund1.PreWithdrawal.Last() * AVPostWithdrawal.Last() / AVPreWithdrawal.Last() );
            Fund2.AddPostWithdrawal(AVPostWithdrawal.Last() == 0 ? 0.0 :
                Fund2.PreWithdrawal.Last() * AVPostWithdrawal.Last() / AVPreWithdrawal.Last());

            Fund1.AddPostCharges(AVPostCharges.Last() == 0 ? 0.0 :
                Fund1.PostWithdrawal.Last() * AVPostCharges.Last() / AVPostWithdrawal.Last());
            Fund2.AddPostCharges(AVPostCharges.Last() == 0 ? 0.0 :
                Fund2.PostWithdrawal.Last() * AVPostCharges.Last() / AVPostWithdrawal.Last());

            Fund1.AddPostDeathClaims(AVPostDeathClaims.Last() == 0 ? 0.0 :
                Fund1.PostCharges.Last() * AVPostDeathClaims.Last() / AVPostCharges.Last());
            Fund2.AddPostDeathClaims(AVPostDeathClaims.Last() == 0 ? 0.0 :
                Fund2.PostCharges.Last() * AVPostDeathClaims.Last() / AVPostCharges.Last());

            Fund1.AddPostRebalance(
                RebalanceIndicator.Last() == 1? AVPostDeathClaims.Last()
                * VariableAnnuityRiskFacotor.FixedAllocationFundsAutomaticRebalancingTarget
                : Fund1.PostDeathClaims.Last());
            Fund2.AddPostRebalance(AVPostCharges[year] - Fund1.PostRebalance[year]);

            DeathBenefitCashFlow.AddNARDeathClaims(
                Math.Max(0, DeathBenefitCashFlow.DeathPayment.Last() - AVPostCharges.Last() )
                );

            LifePayPlusRider.AddDeathBenefitBase(Math.Max(0.0,
                LifePayPlusRider.DeathBenefitBase.Last()* (1.0 - MortalityDictionary[AgeList[year]])
                + Contribution.Last() - MandEFee.Last() - LifePayPlusRider.WithdrawalAmount.Last()
                - LifePayPlusRider.RiderCharge.Last()
                ));

            WithdrawalClaims.Add(Math.Max(0.0, LifePayPlusRider.WithdrawalAmount[year]
                - AVPostDeathClaims[year-1]));
        }


        


        PVCalculator PV_DB_Claim_Calculator = new PVCalculator(
            DiscountFactor, DeathBenefitCashFlow.NARDeathClaims);
        double PV_DB_Claim = PV_DB_Claim_Calculator.CalculatePV();
        PVCalculator PV_WB_Claim_Calculator = new PVCalculator(
            DiscountFactor, WithdrawalClaims);
        double PV_WB_Claim = PV_WB_Claim_Calculator.CalculatePV();
        PVCalculator PV_RC_Calculator = new PVCalculator(
            DiscountFactor, LifePayPlusRider.RiderCharge);
        double PV_RC = PV_RC_Calculator.CalculatePV();
        //Console.WriteLine(PV_DB_Claim);

        var Headers = new List<string> { "Age", "Contribution",
            "AV Pre-Fee", "Fund1 Pre-Fee", "Fund2 Pree-Fee", "M&E/Fund Fees",
            "AV Pre-Withdrawal", "Fund1 Pre-Withdrawal", "Fund2 Pre-Withdrawal",
            "Withdrawal Amount", "AV Post-Withdrawal", "Fund1 Post-Withdrawal", "Fund2 Post-Withdrawal",
            "Rider Charge", "AV Post-Charges", "Fund1 Post-Charges", "Fund2 Post-Charges",
            "Death Payments", "AV Post-Death Claims",
            "Fund1 Post-Death Claims", "Fund2 Post-Death Claims", "Fund1 Post-Rebalance", "Fund2 Post-Rebalance",
            "ROP Death Base", "NAR Death Claims",
            "Death Benefit base", "Withdrawal Base", "Withdrawal Amount", "Cumulative Withdrawal",
            "Maximum Annual Withdrawal", "Maximum Annual Withdrawal Rate",
            " ", "Eligible Step-Up", "Growth Phase", "Withdrawal Phase",
            "Automatic Periodic Benefit Status", "LastDeath",
            " ", "Death Claims", "Withdrawal Claims", "Rider Charges"};


        var Data = new List<List<string>>();
        for (int year = 0; year + StartAge <= VariableAnnuityRiskFacotor.LastDeathAge; year++)
        {
            var Row = new List<string>();
            Row.Add(AgeList[year].ToString());
            Row.Add(Contribution[year].ToString("F0"));
            Row.Add(AVPreFee[year].ToString("F0"));
            Row.Add(Fund1.PreFee[year].ToString("F0"));
            Row.Add(Fund2.PreFee[year].ToString("F0"));
            Row.Add(MandEFee[year].ToString("F0"));
            Row.Add(AVPreWithdrawal[year].ToString("F0"));
            Row.Add(Fund1.PreWithdrawal[year].ToString("F0"));
            Row.Add(Fund2.PreWithdrawal[year].ToString("F0"));
            Row.Add(LifePayPlusRider.WithdrawalAmount[year].ToString("F0"));
            Row.Add(AVPostWithdrawal[year].ToString("F0"));
            Row.Add(Fund1.PostWithdrawal[year].ToString("F0"));
            Row.Add(Fund2.PostWithdrawal[year].ToString("F0"));
            Row.Add(LifePayPlusRider.RiderCharge[year].ToString("F0"));
            Row.Add(AVPostCharges[year].ToString("F0"));
            Row.Add(Fund1.PostCharges[year].ToString("F0"));
            Row.Add(Fund2.PostCharges[year].ToString("F0"));
            Row.Add(DeathBenefitCashFlow.DeathPayment[year].ToString("F0"));
            Row.Add(AVPostDeathClaims[year].ToString("F0"));
            Row.Add(Fund1.PostDeathClaims[year].ToString("F0"));
            Row.Add(Fund2.PostDeathClaims[year].ToString("F0"));
            Row.Add(Fund1.PostRebalance[year].ToString("F0"));
            Row.Add(Fund2.PostRebalance[year].ToString("F0"));
            Row.Add(DeathBenefitCashFlow.ROPDeathBase[year].ToString("F0"));
            Row.Add(DeathBenefitCashFlow.NARDeathClaims[year].ToString("F0"));
            Row.Add(LifePayPlusRider.DeathBenefitBase[year].ToString("F0"));
            Row.Add(LifePayPlusRider.WithdrawalBase[year].ToString("F0"));
            Row.Add(LifePayPlusRider.WithdrawalAmount[year].ToString("F0"));
            Row.Add(LifePayPlusRider.CumulativeWithdrawal[year].ToString("F0"));
            Row.Add(LifePayPlusRider.MaximunAnnualWithdrawal[year].ToString("F0"));
            Row.Add(LifePayPlusRider.MaximunAnnualWithdrawalRate[year].ToString());
            Row.Add(" ");
            Row.Add(EligibleStepUp[year].ToString());
            Row.Add(GrowthPhase[year].ToString());
            Row.Add(WithdrawalPhase[year].ToString());
            Row.Add(AutomaticPeriodicBenefitStatus[year].ToString());
            Row.Add(LastDeath[year].ToString());
            Row.Add(" ");
            Row.Add(DeathBenefitCashFlow.NARDeathClaims[year].ToString("F0"));
            Row.Add(WithdrawalClaims[year].ToString("F0"));
            Row.Add(LifePayPlusRider.RiderCharge[year].ToString("F0"));
            Data.Add(Row);
        }

        var Writer = new CSVwriter(@"./../../../Outputs/CashFlow.csv");
        Writer.Write(Headers, Data);

        using (StreamWriter writer = new StreamWriter(@"./../../../Outputs/PV.csv"))
        {
            writer.WriteLine("PV,Value");

            writer.WriteLine("PV_DB_Claim," + PV_DB_Claim.ToString("F0"));
            writer.WriteLine("PV_DW_Claim," + PV_WB_Claim.ToString("F0"));
            writer.WriteLine("PV_RC," + PV_RC.ToString("F0"));
        }

    }
}
