﻿using System;
namespace VariableAnnuityCashFlow
{
    public interface IDeathBenefit
    {
        public List<double>? ROPDeathBase { get; set; }
        public List<double>? NARDeathClaims { get; set; }
        public List<double>? DeathPayment { get; set; }

        void AddROPDeathBase(double amount);
        void AddNARDeathClaims(double amount);
        void AddDeathPayment(double amount);
    }

    public abstract class BaseDeathBenefit : IDeathBenefit
    {
        public List<double>? ROPDeathBase { get; set; }
        public List<double>? NARDeathClaims { get; set; }
        public List<double>? DeathPayment { get; set; }

        public abstract void AddROPDeathBase(double amount);
        public abstract void AddNARDeathClaims(double amount);
        public abstract void AddDeathPayment(double amount);
    }

    public class DeathBenefit : BaseDeathBenefit
    {

        public DeathBenefit()
        {
            ROPDeathBase = new List<double>();
            NARDeathClaims = new List<double>();
            DeathPayment = new List<double>();
        }

        public override void AddROPDeathBase(double amount)
        {
            ROPDeathBase.Add(amount);
        }

        public override void AddNARDeathClaims(double amount)
        {
            NARDeathClaims.Add(amount);
        }

        public override void AddDeathPayment(double amount)
        {
            DeathPayment.Add(amount);
        }
    }
}