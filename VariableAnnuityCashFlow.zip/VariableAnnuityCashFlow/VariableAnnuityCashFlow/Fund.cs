﻿using System;
using System.Collections.Generic;
using Newtonsoft.Json;

namespace VariableAnnuityCashFlow
{

    public interface IFund
    {
        double Weight { get; set; }
        List<double>? YearReturn { get; set; }
        List<double>? PreFee { get; set; }
        List<double>? PreWithdrawal { get; set; }
        List<double>? PostWithdrawal { get; set; }
        List<double>? PostCharges { get; set; }

        void AddYearReturn(double amount);
        void AddPreFee(double amount);
        void AddPreWithdrawal(double amount);
        void AddPostWithdrawal(double amount);
        void AddPostCharges(double amount);
        void AddPostDeathClaims(double amount);
        void AddPostRebalance(double amount);
    }

    public abstract class BaseFund : IFund
    {
        public double Weight { get; set; }
        public List<double>? YearReturn { get; set; }
        public List<double>? PreFee { get; set; }
        public List<double>? PreWithdrawal { get; set; }
        public List<double>? PostWithdrawal { get; set; }
        public List<double>? PostCharges { get; set; }
        public List<double>? PostDeathClaims { get; set; }
        public List<double>? PostRebalance { get; set; }

        public abstract void AddYearReturn(double amount);
        public abstract void AddPreFee(double amount);
        public abstract void AddPreWithdrawal(double amount);
        public abstract void AddPostWithdrawal(double amount);
        public abstract void AddPostCharges(double amount);
        public abstract void AddPostDeathClaims(double amount);
        public abstract void AddPostRebalance(double amount);
    }

    public class Fund : BaseFund
    {

        public Fund()
        {
            YearReturn = new List<double>();
            PreFee = new List<double>();
            PreWithdrawal = new List<double>();
            PostWithdrawal = new List<double>();
            PostCharges = new List<double>();
            PostDeathClaims = new List<double>();
            PostRebalance = new List<double>();
        }

        public override void AddYearReturn(double amount)
        {
            YearReturn.Add(amount);
        }

        public override void AddPreFee(double amount)
        {
            PreFee.Add(amount);
        }

        public override void AddPreWithdrawal(double amount)
        {
            PreWithdrawal.Add(amount);
        }

        public override void AddPostWithdrawal(double amount)
        {
            PostWithdrawal.Add(amount);
        }

        public override void AddPostCharges(double amount)
        {
            PostCharges.Add(amount);
        }
        public override void AddPostDeathClaims(double amount)
        {
            PostDeathClaims.Add(amount);
        }
        public override void AddPostRebalance(double amount)
        {
            PostRebalance.Add(amount);
        }
    }

    public class FundConfig
    {
        public double Weight { get; set; }
        public string? ReturnScenario { get; set; }
    }

    public class FundReturn
    {
        public int Year { get; set; }
        public double Return { get; set; }
    }

}




