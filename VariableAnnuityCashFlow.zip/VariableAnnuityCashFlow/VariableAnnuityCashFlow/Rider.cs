﻿using System;
namespace VariableAnnuityCashFlow
{
    public interface IRider
    {
        public List<double>? DeathBenefitBase { get; set; }
        public List<double>? WithdrawalBase { get; set; }
        public List<double>? WithdrawalAmount { get; set; }
        public List<double>? CumulativeWithdrawal { get; set; }
        public List<double>? MaximunAnnualWithdrawal { get; set; }
        public List<double>? MaximunAnnualWithdrawalRate { get; set; }
        public List<double>? RiderCharge { get; set; }

        void AddDeathBenefitBase(double amount);
        void AddWithdrawalBase(double amount);
        void AddWithdrawalAmount(double amount);
        void AddCumulativeWithdrawal(double amount);
        void AddMaximunAnnualWithdrawal(double amount);
        void AddMaximunAnnualWithdrawalRate(double amount);
        void AddRiderCharge(double amount);
    }

    public abstract class BaseRider : IRider
    {
        public List<double>? DeathBenefitBase { get; set; }
        public List<double>? WithdrawalBase { get; set; }
        public List<double>? WithdrawalAmount { get; set; }
        public List<double>? CumulativeWithdrawal { get; set; }
        public List<double>? MaximunAnnualWithdrawal { get; set; }
        public List<double>? MaximunAnnualWithdrawalRate { get; set; }
        public List<double>? RiderCharge { get; set; }

        public abstract void AddDeathBenefitBase(double amount);
        public abstract void AddWithdrawalBase(double amount);
        public abstract void AddWithdrawalAmount(double amount);
        public abstract void AddCumulativeWithdrawal(double amount);
        public abstract void AddMaximunAnnualWithdrawal(double amount);
        public abstract void AddMaximunAnnualWithdrawalRate(double amount);
        public abstract void AddRiderCharge(double amount);
    }

    public class Rider : BaseRider
    {

        public Rider()
        {
            DeathBenefitBase = new List<double>();
            WithdrawalBase = new List<double>();
            WithdrawalAmount = new List<double>();
            CumulativeWithdrawal = new List<double>();
            MaximunAnnualWithdrawal = new List<double>();
            MaximunAnnualWithdrawalRate = new List<double>();
            RiderCharge = new List<double>();
        }

        public override void AddDeathBenefitBase(double amount)
        {
            DeathBenefitBase.Add(amount);
        }

        public override void AddWithdrawalBase(double amount)
        {
            WithdrawalBase.Add(amount);
        }

        public override void AddWithdrawalAmount(double amount)
        {
            WithdrawalAmount.Add(amount);
        }

        public override void AddCumulativeWithdrawal(double amount)
        {
            CumulativeWithdrawal.Add(amount);
        }
        public override void AddMaximunAnnualWithdrawal(double amount)
        {
            MaximunAnnualWithdrawal.Add(amount);
        }
        public override void AddMaximunAnnualWithdrawalRate(double amount)
        {
            MaximunAnnualWithdrawalRate.Add(amount);
        }
        public override void AddRiderCharge(double amount)
        {
            RiderCharge.Add(amount);
        }
    }
}

