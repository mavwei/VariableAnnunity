﻿using System;
using System.Reflection;

namespace VariableAnnuityCashFlow
{
    public class PVCalculator
    {
        public List<double> DiscountFactor { get; set; }
        public List<double> CashFlow { get; set; }

        public PVCalculator(List<double> discountFactor, List<double> cashFlow)
        {
            DiscountFactor = discountFactor;
            CashFlow = cashFlow;
        }

        public double CalculatePV()
        {
            double PV = 0.0;

            for (int index = 0; index < DiscountFactor.Count; index++)
            {
                PV += DiscountFactor[index] * CashFlow[index];
            }


            return PV;
        }

    }

    class DiscountFactor
    {
        public static double CalculateDiscountFactor(double interestRate, double term)
        {
            return Math.Pow((1+ interestRate), -term);
        }
    }

    class MortalityTable
    {
        public int Age { get; set; }
        public double MortalityRate { get; set; }
    }

    class LapseTable
    {
        public int Dur { get; set; }
        public double INGLifePayPlusBase { get; set; }
    }
}

