﻿using System;
namespace VariableAnnuityCashFlow
{
    public class VariableAnnuity
    {
        public double StepUp { get; set; }
        public int StepUpPeriod { get; set; }
        public double RiderCharge { get; set; }
        public double InitialPremium { get; set; }
        public int StartAge { get; set; }
        public int FirstWithdrawalAge { get; set; }
        public int AnnunityCommencementDateAge { get; set; }
        public int LastDeathAge { get; set; }
        public double Mortality { get; set; }
        public double WithrawalRate { get; set; }
        public double FixedAllocationFundsAutomaticRebalancingTarget { get; set; }
        public double MandE { get; set; }
        public double FundFees { get; set; }
        public double RiskFreeRate { get; set; }
        public double Volatility { get; set; }
        public Dictionary<string, double>? MaxAnnualWithdrawal { get; set; }
    }
}

