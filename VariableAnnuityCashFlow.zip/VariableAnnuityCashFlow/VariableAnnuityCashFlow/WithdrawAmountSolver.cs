﻿using System;
namespace VariableAnnuityCashFlow
{
	public class WithdrawalSolver
	{
        private double Contribution;
        private double AVPreWithdrawal;
        private double AVPostWithdrawal;
        private double AVPostDeathClaims;
        private double AVPostCharges;
        private double MandEFee;
        private double RiderCharge;
        private double RiderChargeRate;

        private double MortalityRate;

        private double DeathBenefit;
        private double WithdrawBase;
        private double WithdrawBaseLastYear;
        private double WithdrawalAmount;
        private double MaxWithdrawalAmount;
        private double DeathPayment;

        private double StepUp;
        private int EligibleStepUp;
        private int AutomaticPeriodicBenefitStatus;
        private int WithdrawalPhase;
        private double WithrawalRate;
        double MaxAnnualWithdrawalRate;
        private int GrowthPhase;

        public WithdrawalSolver(
            double Contribution,
            double AVPreWithdrawal,
            double MandEFee,
            double RiderChargeRate,
            double MortalityRate,
            double DeathBenefit,
            double WithdrawBaseLastYear,
            double MaxWithdrawalAmount,
            double DeathPayment,
            double StepUp,
            int EligibleStepUp,
            int WithdrawalPhase,
            int AutomaticPeriodicBenefitStatus,
            double WithrawalRate,
            double MaxAnnualWithdrawalRate,
            int GrowthPhase
            )
		{
            this.Contribution = Contribution;
            this.AVPreWithdrawal = AVPreWithdrawal;
            this.MandEFee = MandEFee;
            this.RiderChargeRate = RiderChargeRate;
            this.MortalityRate = MortalityRate;
            this.DeathBenefit = DeathBenefit;
            this.WithdrawBaseLastYear = WithdrawBaseLastYear;
            this.MaxWithdrawalAmount = MaxWithdrawalAmount;
            this.DeathPayment = DeathPayment;
            this.StepUp = StepUp;
            this.EligibleStepUp = EligibleStepUp;
            this.WithdrawalPhase = WithdrawalPhase;
            this.AutomaticPeriodicBenefitStatus = AutomaticPeriodicBenefitStatus;
            this.WithrawalRate = WithrawalRate;
            this.MaxAnnualWithdrawalRate = MaxAnnualWithdrawalRate;
            this.GrowthPhase = GrowthPhase;
        }

        public double CalculateAVPostCharges()
        {
            return AVPostWithdrawal - RiderCharge;
        }
        public double ReturnAVPostCharges
        {
            get { return AVPostCharges; }
        }

        public double CalculateAVPostDeathClaims()
        {
            return Math.Max(AVPostCharges - DeathPayment, 0);
        }
        public double ReturnAVPostDeathClaims
        {
            get { return AVPostDeathClaims; }
        }

        public double CalculateWithdrawBase()
        {
            return Math.Max(Math.Max(
                GrowthPhase == 1 ? AVPostDeathClaims : 0,
                WithdrawBaseLastYear * (1 - MortalityRate) + Contribution ),
                EligibleStepUp == 1 ? (WithdrawBaseLastYear * (1.0 - MortalityRate) * (1.0 + StepUp)
                + Contribution - MandEFee - RiderCharge) : 0 );
        }
        public double ReturnWithdrawBase
        {
            get { return WithdrawBase; }
        }

        public double CalculateWithdrawalAmount()
        {
            return WithdrawalPhase == 1 ? WithrawalRate * WithdrawBase :
                (AutomaticPeriodicBenefitStatus == 1 ? MaxWithdrawalAmount : 0);
        }


        public double CalculateMaxWithdrawalAmount()
        {
            return WithdrawBase* MaxAnnualWithdrawalRate;
        }
        public double ReturnMaxWithdrawalAmount
        {
            get { return MaxWithdrawalAmount; }
        }


        public double CalculateAVPostWithdrawal()
        {
            return Math.Max(AVPreWithdrawal - WithdrawalAmount, 0);
        }
        public double ReturnAVPostWithdrawal
        {
            get { return AVPostWithdrawal; }
        }


        public double CalculateRiderCharge()
        {
            return RiderChargeRate * AVPostWithdrawal;
        }
        public double ReturnRiderCharge
        {
            get { return RiderCharge; }
        }

        public double Calculator(int MaxIterations = 100, double MaxAllowedChange = 0.001)
        {
            double CurrentChange = 1.0;
            int Iteration = 0;
            double GuessAVPostCharges = 0.0;
            double GuessAVPostDeathClaims = 0.0;
            double GuessWithdrawBase = WithdrawBaseLastYear - 1;
            double GuessWithdrawalAmount = WithdrawBaseLastYear;
            double GuessMaxWithdrawalAmount = WithdrawBaseLastYear;
            double GuessAVPostWithdrawal = 0.0;
            double GuessRiderCharge = 0.0;

            while (Iteration < MaxIterations && CurrentChange > MaxAllowedChange)
            {
                AVPostCharges = CalculateAVPostCharges();
                AVPostDeathClaims = CalculateAVPostDeathClaims();

                WithdrawBase = CalculateWithdrawBase();

                WithdrawalAmount = CalculateWithdrawalAmount();
                MaxWithdrawalAmount = CalculateMaxWithdrawalAmount();
                AVPostWithdrawal = CalculateAVPostWithdrawal();
                RiderCharge = CalculateRiderCharge();

                CurrentChange = Math.Abs(WithdrawBase - GuessWithdrawBase)
                    + Math.Abs(AVPostCharges - GuessAVPostCharges)
                    + Math.Abs(AVPostDeathClaims - GuessAVPostDeathClaims)
                    + Math.Abs(WithdrawalAmount - GuessWithdrawalAmount)
                    + Math.Abs(MaxWithdrawalAmount - GuessMaxWithdrawalAmount)
                    + Math.Abs(AVPostWithdrawal - GuessAVPostWithdrawal)
                    + Math.Abs(RiderCharge - GuessRiderCharge);
                GuessWithdrawBase = WithdrawBase;
                GuessAVPostCharges = AVPostCharges;
                GuessAVPostDeathClaims = AVPostDeathClaims;
                GuessWithdrawalAmount = WithdrawalAmount;
                GuessMaxWithdrawalAmount = MaxWithdrawalAmount;
                GuessAVPostWithdrawal = AVPostWithdrawal;
                GuessRiderCharge = RiderCharge;
                Iteration++;
            }
            
            return WithdrawalAmount;
        }

    }
}

